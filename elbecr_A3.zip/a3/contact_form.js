$(document).ready(function() {
    /*add code here to validate your form*/
    $("#contactForm").validate({
        rules: {
            FirstName:{required:true, rangelength: [2,30] },
            LastName:{required:true, rangelength: [2,30]},
            EmailAddress:{required:true,email:true}
        }
        ,messages:{
            FirstName:{required:"Enter your first name.", rangelength:"Must be between 2 and 30 characters."},
           
            LastName:{required:"Enter your last name.", rangelength:"Must be between 2 and 30 characters"},
            
            EmailAddress:{required:"Enter a valid Email Address"}
       
        
        }
    });
}); // end ready