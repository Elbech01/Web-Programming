$(document).ready(function(){
    /***Add all your code here***/
	$(".bxslider").bxSlider({
        autoControl:true,
        mode: 'fade',
        captions:true,
        slideWidth:400
    });
    $(".bxslider img").mouseenter(function(){$(this).css({"opacity":"0.8"});});
    $(".bxslider img").mouseout(function(){$(this).css({"opacity":"1"});});
   
    $("h1").animate(
    {fontSize:"225%",opacity:1,left:0},2000);
   
    $(".bxslider img").click(function(){
        var a = $(this);
        $("#dialog").dialog({modal:true,width:800,buttons:{
            Cancel:function(){
                $(this).dialog("close");
            },
            Show:function(){
                $("#label").text(a.attr("desc"));
                }
            }
        });
    })

})