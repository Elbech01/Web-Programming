$(document).ready(function(){
       
       
        var numSongs = "";  			//Adding a variable for the total results given
            $("#slider").slider({
            orientation: "horizontal",
            min:10,
            max:30,				//Slider code for the plugin
            value: 10,
            slide: updateText,
            change: updateText
        });
        function updateText(){
            numSongs = $("#slider").slider("value");	
            $("#sliderVal").text(numSongs);		//Updates the text next to the slider
            }
        $("#btnLook").click(function() {		//When look button is clicked
           
            $("#songList").html("");		//Clears the div called songList
               
                var country = $("#country :selected").val();		//Retrieving the country that the user selected from the drop down menu
                var itunesRSS = "https://itunes.apple.com/"+ country + "/rss/topsongs/limit=" + numSongs + "/xml"; //Sets the RSS feed from a certain country chosen  
                var songTitle = "";		//Variable for the song title											  //with number of songs from the slider for itunes
        
		$.get(itunesRSS, function(data) {			//Gets the RSS feed from itunes
                var songs = $(data).find("entry");	//Sets a variable for the array of songs found from RSS feed
                songs.each(function() {				//For each song...
                    var title = $(this).find("title").text();	//Finds the title tag in the RSS feed
                    var album = $(this).find("im\\:collection").children("im\\:name").text();	//Finds the album name from RSS feed
					var link = $(this).find("link").attr("href");	//Finds the audio link from the RSS feed
					var songName = $(this).find("im\\:name").eq(0).text();	//Finds the song name from the RSS feed
                    var songImage = $(this).find("im\\:image").eq(1).text();//Finds the image tag in the RSS feed
                    var audio = $(this).find("link").eq(1).attr("href");	//Finds the audio clip from the RSS feed
                    var name = $(this).find("im\\:artist").text();	//Finds the name of the artist from the RSS feed
                    
                    
                    songTitle = $(this).find("title").text();		
                    var youtubeAPI = "https://www.googleapis.com/youtube/v3/search?q=" + songTitle + "&part=snippet&maxResults=1&key=AIzaSyD9wZ_-iZkUbgiV2bodpM-eNlU-25WusqU";
                    $.getJSON(youtubeAPI, function(data){		//Gets YouTube API RSS Feed
                    var id = data.items[0].id.videoId;		//Gets the video ID	
                    var title = data.items[0].snippet.title;	//Gets the title of the video
                    var youtubelink = "https://www.youtube.com/watch?v=" + id;	//Gets the video link from the API
                    $("#songList").append(		//Adds the song list to the div
                        "<h2>Title: " + songName + " — " + name + "</h2> " + "<h2>Album: " + album + "</h2>"  +
                         "<h2>ITunes Link: </h2><a href='" + link + "'>" + link + "</a> <br>" +					//Gives HTML text to the div to display
                        "<h2>YouTube Link: </h2><a href='" + youtubelink + "'>" + youtubelink + "</a><br>" +		
                        "<br> <img src='" + songImage + "'/> <br>" +
                        "<audio controls>" + "<source src='" + audio + "'>" + "</audio>" //Gives controls for the audio to the user
                        );
                });
                });
            }, "xml");
});
});
