var bill = parseFloat(prompt("Enter bill total"));
var tip1 = bill * .15;
var tip2 = bill * .2;
alert("Total bill: " + bill + "\n15% Tip = " + tip1 + " and 20% Tip = " + tip2);