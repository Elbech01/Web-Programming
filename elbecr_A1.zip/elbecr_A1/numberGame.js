var number = Math.floor((Math.random() * 100) + 1);
var input = parseFloat(prompt("Enter a number between 1 and 100"));
while (input != number)
{
	if (input < number)
	{
		alert("Your number is too low.");
	}
	else{
		alert("Your number is too high");
	}
	input = parseFloat(prompt("Enter a number between 1 and 100"));
}
alert("You got it!");