var price1 = parseFloat(prompt("Enter Item 1 Price"));	
var price2 = parseFloat(prompt("Enter Item 2 Price"));
var subtotal = (price1 + price2);
var tax = (subtotal * .06);
var total = (subtotal + tax);
alert("Cost of Item 1: " + price1.toFixed(2) + "\nCost of Item 2: " + price2.toFixed(2) + "\nTotal Price of two items: " + subtotal.toFixed(2) + "\n6% sales tax: " + tax.toFixed(2) + "\nTotal Cost: " + total.toFixed(2));
