var number = parseFloat(prompt("Enter a Number 1-5"));
var isValid = true;
while(isNaN(number) == true || number < 1 || number > 5) {
			alert("Please enter a number between 1 and 5");
			number = parseFloat(prompt("Enter a Number 1-5"));
		}
	if (number == 1)
	{
		alert("You will have much luck this year.");
	}
	else if (number == 2)
	{
		alert("You won't get a promotion this year.");
	}
	else if (number == 3)
	{
		alert("Something good may happen for you in the next two days.");
	}
	else if (number == 4)
	{
		alert("You will win the lottery in 14 years.");
	}
	else
	{
		alert("You will have to give up somehthing important to you soon.");
	}